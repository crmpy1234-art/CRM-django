"""
URL configuration for cfehome project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include

from contacts.views import contacts_list_view, contacts_detail_view
from dashboard.views import dashboard_webpage, about_us_page

urlpatterns = [
    path("", dashboard_webpage),
    path("contacts/<int:contact_id>/", contacts_detail_view),
    path("contacts/", contacts_list_view),
    path("dashboard/", dashboard_webpage),
    path("about/", about_us_page),
    path("admin/", admin.site.urls),
    path("auth/", include("django_googler.urls.default")),
]
